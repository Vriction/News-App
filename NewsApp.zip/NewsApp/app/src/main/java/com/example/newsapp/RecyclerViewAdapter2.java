package com.example.newsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerViewAdapter2 extends RecyclerView.Adapter<RecyclerViewAdapter2.viewHolder2>{
    private List<Story2> storySwipe;
    private Context context;

    public RecyclerViewAdapter2 (List<Story2> storySwipe, Context context)
    {
        this.storySwipe = storySwipe;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerViewAdapter2.viewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View storyView = LayoutInflater.from(context).inflate(R.layout.story_layout2, parent, false);

        return new RecyclerViewAdapter2.viewHolder2(storyView);
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter2.viewHolder2 holder, int position)
    {
        holder.topStorySwipe.setImageResource(storySwipe.get(position).getImage());
        holder.storyText.setText(storySwipe.get(position).getTitle());
    }

    @Override
    public int getItemCount()
    {
        return storySwipe.size();
    }

    public class viewHolder2 extends RecyclerView.ViewHolder
    {
        public ImageView topStorySwipe;
        public TextView storyText;

        public viewHolder2(@NonNull View storyView)
        {
            super(storyView);
            topStorySwipe = storyView.findViewById(R.id.imageViewFrag);
            storyText = storyView.findViewById(R.id.storyText2);
        }
    }
}
