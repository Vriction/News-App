package com.example.newsapp;

public class Story {
    private int image;

    public Story(int image)
    {
        this.image = image;
    }

    public int getImage()
    {
        return image;
    }

    public void setImage (int image)
    {
        this.image = image;
    }
}
