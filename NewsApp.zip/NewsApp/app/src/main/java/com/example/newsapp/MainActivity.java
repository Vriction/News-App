package com.example.newsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView topStoryView;

    RecyclerViewAdapter storyAdapter;

    List<Story> storyList = new ArrayList<>();

    Integer[] storyInteger = {R.drawable.joni2, R.drawable.elontweert, R.drawable.coronavirus};

    ImageView strangeImage;

    View fragmentContainer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        strangeImage = findViewById(R.id.strangeImageClick);

        fragmentContainer = findViewById(R.id.fragmentContainerView);
        fragmentContainer.setVisibility(View.INVISIBLE);

        topStoryView = findViewById(R.id.storyRecycle);
        storyAdapter = new RecyclerViewAdapter(storyList, MainActivity.this);

        topStoryView.setAdapter(storyAdapter);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        topStoryView.setLayoutManager(layoutManager);

        for (int i = 0; i < storyInteger.length; i++)
        {
            storyList.add(new Story(storyInteger[i]));
        }

        //IMAGE

        strangeImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment fragment;

                fragment = new NewsFragment();

                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragmentContainerView, fragment)
                        .commit();

                fragmentContainer.setVisibility(View.VISIBLE);
//.addToBackStack(null)

//                RecyclerView topStoryView2;
//
//                RecyclerViewAdapter2 storyAdapter2;
//
//                List<Story2> storyList2 = new ArrayList<>();
//                Integer[] storyInteger2 = {R.drawable.joni2, R.drawable.joni2};
//                String[] titleStr2 = {"LMAO", "MAO"};
//
//                //next rec view names
//                topStoryView2 = findViewById(R.id.storyRecycle2);
//                storyAdapter2 = new RecyclerViewAdapter2(storyList2, MainActivity.this);
//
//                topStoryView2.setAdapter(storyAdapter2);
//
//                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
//                topStoryView2.setLayoutManager(layoutManager);
//
//                for (int i = 0; i < storyInteger2.length; i++)
//                {
//                    storyList2.add(new Story2(storyInteger2[i], titleStr2[i]));
//                }


            }
        });

    }
}