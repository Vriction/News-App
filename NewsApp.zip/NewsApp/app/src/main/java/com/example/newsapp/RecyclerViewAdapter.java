package com.example.newsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.viewHolder>
{
    private List<Story> storySwipe;
    private Context context;

    public RecyclerViewAdapter (List<Story> storySwipe, Context context)
    {
        this.storySwipe = storySwipe;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerViewAdapter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View storyView = LayoutInflater.from(context).inflate(R.layout.story_layout, parent, false);

        return new viewHolder(storyView);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position)
    {
        //holder.topStorySwipe.setImageResource(storySwipe.get(position).getImage());
        holder.topStorySwipe.setImageResource(storySwipe.get(position).getImage());
    }

    @Override
    public int getItemCount()
    {
        return storySwipe.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder
    {
        public ImageView topStorySwipe;

        public viewHolder(@NonNull View storyView)
        {
            super(storyView);
            topStorySwipe = storyView.findViewById(R.id.imageView);
        }
    }
}


