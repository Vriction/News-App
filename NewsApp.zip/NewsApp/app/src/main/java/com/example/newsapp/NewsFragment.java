package com.example.newsapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link NewsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NewsFragment extends Fragment {

    public NewsFragment() {
        // Required empty public constructor
    }

    public static NewsFragment newInstance(String param1, String param2) {
        NewsFragment fragment = new NewsFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View test = inflater.inflate(R.layout.fragment_news, container, false);

        RecyclerView topStoryView2;

        RecyclerViewAdapter2 storyAdapter2;

        List<Story2> storyList2 = new ArrayList<>();
        Integer[] storyInteger2 = {R.drawable.joni2, R.drawable.elontweert};
        String[] titleStr2 = {"Johnny Depp Case", "Elon Musk and Twitter"};

        //next rec view names
        topStoryView2 = test.findViewById(R.id.storyRecycle2);
        storyAdapter2 = new RecyclerViewAdapter2(storyList2, getActivity());

        topStoryView2.setAdapter(storyAdapter2);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        topStoryView2.setLayoutManager(layoutManager);

        for (int i = 0; i < storyInteger2.length; i++)
        {
            storyList2.add(new Story2(storyInteger2[i], titleStr2[i]));
        }

        return test;
    }
}